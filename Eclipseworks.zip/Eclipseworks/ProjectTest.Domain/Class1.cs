﻿namespace ProjectTest.Domain
{
    public class Class1
    {

    }
}
