﻿namespace ProjectTest.Helpers
{
    public class Class
    {
    }
}
