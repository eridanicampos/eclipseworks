﻿namespace ProjectTest.Infrastructure
{
    public class Class1
    {

    }
}
